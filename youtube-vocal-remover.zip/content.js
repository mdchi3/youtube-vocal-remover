// Content script para procesamiento de audio en tiempo real en YouTube
(() => {
  let audioCtx = null;
  let sourceNode = null;
  let normalGain = null;
  let karaokeGain = null;
  let isVocalRemoved = false;
  let currentVideoElement = null;

  // Inicializar o reconectar la cadena de audio de la Web Audio API
  function initAudioNodes(video) {
    if (!video) return;

    // Si ya está conectado a este video, no recrear
    if (audioCtx && currentVideoElement === video) {
      return;
    }

    currentVideoElement = video;

    try {
      if (!audioCtx) {
        const AudioContextClass = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AudioContextClass();
      }

      if (audioCtx.state === 'suspended') {
        const resumeAudio = () => {
          if (audioCtx && audioCtx.state === 'suspended') {
            audioCtx.resume();
          }
        };
        video.addEventListener('play', resumeAudio, { once: true });
        window.addEventListener('click', resumeAudio, { once: true });
      }

      if (!sourceNode) {
        sourceNode = audioCtx.createMediaElementSource(video);

        // 1. Canal Directo (Audio Normal Original)
        normalGain = audioCtx.createGain();
        normalGain.gain.value = isVocalRemoved ? 0 : 1;
        sourceNode.connect(normalGain);
        normalGain.connect(audioCtx.destination);

        // 2. Canal Karaoke / Vocal Remover (Cancelación de voz centrada estéreo)
        // La voz de canciones suele estar paneada exactamente en el centro (L = R).
        // Al invertir una de las fases: Audio_Karaoke = L - R
        // Los instrumentos estereo (guitarras, teclados, reverberación, efectos) se mantienen.
        const splitter = audioCtx.createChannelSplitter(2);
        const merger = audioCtx.createChannelMerger(2);

        const invertGain = audioCtx.createGain();
        invertGain.gain.value = -1; // Invertir fase del canal derecho

        const subGain = audioCtx.createGain();
        subGain.gain.value = 1;

        // Conectar L y R al splitter
        sourceNode.connect(splitter);

        // Left va directo a subGain
        splitter.connect(subGain, 0); // Entrada 0 (Left)

        // Right va invertido a subGain
        splitter.connect(invertGain, 1); // Entrada 1 (Right)
        invertGain.connect(subGain);

        // subGain contiene ahora (Left - Right) -> Señal sin elementos centrados (voz removida)
        // Enviamos (L - R) a ambos oídos para que se escuche en ambos canales
        subGain.connect(merger, 0, 0); // Al Left del merger
        subGain.connect(merger, 0, 1); // Al Right del merger

        karaokeGain = audioCtx.createGain();
        karaokeGain.gain.value = isVocalRemoved ? 1 : 0;

        merger.connect(karaokeGain);
        karaokeGain.connect(audioCtx.destination);
      }
    } catch (err) {
      console.warn('[VocalRemover] No se pudo inicializar Web Audio:', err);
    }
  }

  // Activar o desactivar al instante
  function setVocalRemoval(enabled) {
    isVocalRemoved = enabled;

    const video = document.querySelector('video');
    if (video) {
      initAudioNodes(video);
    }

    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    if (normalGain && karaokeGain && audioCtx) {
      const now = audioCtx.currentTime;
      // Transición ultra rápida (5ms) para evitar chasquidos acústicos ("clicks"), pero imperceptible al oído
      normalGain.gain.cancelScheduledValues(now);
      karaokeGain.gain.cancelScheduledValues(now);

      if (enabled) {
        normalGain.gain.setValueAtTime(normalGain.gain.value, now);
        normalGain.gain.linearRampToValueAtTime(0, now + 0.005);

        karaokeGain.gain.setValueAtTime(karaokeGain.gain.value, now);
        karaokeGain.gain.linearRampToValueAtTime(1, now + 0.005);
      } else {
        normalGain.gain.setValueAtTime(normalGain.gain.value, now);
        normalGain.gain.linearRampToValueAtTime(1, now + 0.005);

        karaokeGain.gain.setValueAtTime(karaokeGain.gain.value, now);
        karaokeGain.gain.linearRampToValueAtTime(0, now + 0.005);
      }
    }

    // Persistir estado
    chrome.storage.local.set({ vocalRemoved: isVocalRemoved });
  }

  // Escuchar mensajes del popup o atajos de teclado
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'GET_STATUS') {
      sendResponse({ enabled: isVocalRemoved });
      return true;
    }

    if (request.action === 'TOGGLE_VOCAL') {
      setVocalRemoval(!isVocalRemoved);
      sendResponse({ enabled: isVocalRemoved });
      return true;
    }

    if (request.action === 'SET_VOCAL') {
      setVocalRemoval(!!request.enabled);
      sendResponse({ enabled: isVocalRemoved });
      return true;
    }
  });

  // Restaurar estado previo guardado
  chrome.storage.local.get(['vocalRemoved'], (res) => {
    if (res && res.vocalRemoved) {
      isVocalRemoved = true;
    }
  });

  // Observar navegación en YouTube (SPA: cambia de video sin recargar)
  const observer = new MutationObserver(() => {
    const video = document.querySelector('video');
    if (video && video !== currentVideoElement) {
      initAudioNodes(video);
      setVocalRemoval(isVocalRemoved);
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  // Hook inicial
  window.addEventListener('load', () => {
    const video = document.querySelector('video');
    if (video) {
      initAudioNodes(video);
    }
  });
})();

