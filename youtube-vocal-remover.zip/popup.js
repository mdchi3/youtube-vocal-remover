document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('vocalToggle');
  const statusLabel = document.getElementById('statusLabel');

  function updateStatus(enabled) {
    toggle.checked = enabled;
    if (enabled) {
      statusLabel.textContent = 'Voz eliminada (Karaoke)';
      statusLabel.style.color = '#ff0033';
    } else {
      statusLabel.textContent = 'Voz original activa';
      statusLabel.style.color = '#888';
    }
  }

  // Consultar estado actual a la pestaña activa de YouTube
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length === 0) return;
    const tabId = tabs[0].id;

    chrome.tabs.sendMessage(tabId, { action: 'GET_STATUS' }, (response) => {
      if (chrome.runtime.lastError || !response) {
        // Si no está en YouTube o no ha cargado el content script
        chrome.storage.local.get(['vocalRemoved'], (res) => {
          updateStatus(!!(res && res.vocalRemoved));
        });
      } else {
        updateStatus(!!response.enabled);
      }
    });
  });

  // Al hacer clic en el switch
  toggle.addEventListener('change', () => {
    const isChecked = toggle.checked;
    updateStatus(isChecked);

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length === 0) return;
      const tabId = tabs[0].id;

      chrome.tabs.sendMessage(tabId, { action: 'SET_VOCAL', enabled: isChecked });
    });
  });
});

